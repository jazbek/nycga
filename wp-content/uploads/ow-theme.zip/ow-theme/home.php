<?php 

if (is_user_logged_in()){

	bp_core_redirect('activity');
	}
else
	locate_template( array( 'page-home.php'), true);

	
?>