<?php 

if (is_user_logged_in())

	locate_template( array( 'activity/index.php' ), true );
else
	locate_template( array( 'page-home.php'), true);
	
?>