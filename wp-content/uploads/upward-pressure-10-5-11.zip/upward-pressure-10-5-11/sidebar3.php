<div id="sidebar-tweets">
	<div class="paddersidebar">
	

	<?php if ( !dynamic_sidebar('sidebar3')): ?>
    
    <div class="widget-container">
    <p>some text here</p>
    </div>

	

   
 <?php endif; ?>
 
	</div>
 </div>

